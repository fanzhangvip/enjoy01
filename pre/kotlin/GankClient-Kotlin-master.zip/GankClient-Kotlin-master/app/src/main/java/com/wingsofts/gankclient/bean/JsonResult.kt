package com.wingsofts.gankclient.bean

/**
 * Created by wing on 11/23/16.
 */
class JsonResult<T>(val error :Boolean,
                    val results:T){
}