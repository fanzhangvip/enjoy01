package com.wingsofts.gankclient.router

/**
 * Created by wing on 16-11-24.
 */
object GankClientUri {
    //关于Activity
    const val ABOUT = "gank://androidwing.net/about/"




    //详情页
    const val DETAIL_PARAM_URL = "url"
    const val DETAIL = "gank://androidwing.net/detail/"
}